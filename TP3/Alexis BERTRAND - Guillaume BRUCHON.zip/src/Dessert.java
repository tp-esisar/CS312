
public class Dessert extends Plat {
	public Dessert(String nom,  int prix) {
		super(nom, prix);
	}
}
