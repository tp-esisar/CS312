

public class Entr�e extends Plat {
	public Entr�e(String nom, int prix) {
		super(nom, prix);
	}
}
