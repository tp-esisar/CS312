
public class PlatPrincipal extends Plat {
	public PlatPrincipal(String nom, int prix) {
		super(nom, prix);
	}
}
