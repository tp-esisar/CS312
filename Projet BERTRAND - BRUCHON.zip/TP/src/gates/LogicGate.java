package gates;

public enum LogicGate {
	NONE,AND,NAND,NOR,NOT,OR,XOR,BUTTON,LED
}
